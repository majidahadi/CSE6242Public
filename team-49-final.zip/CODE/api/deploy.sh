gcloud app deploy -v prod -q --promote

gsutil cp *.json gs://cse6242a
gsutil cp genres/*.csv gs://cse6242a

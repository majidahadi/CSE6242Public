cd $1
find . -mindepth 2 -type f -exec mv -t . -n '{}' +
rm -rf 1997
rm -rf 1998
rm -rf 1999
rm -rf 2000
rm -rf 2001
rm -rf 2002
rm -rf 2003
rm -rf 2004
rm -rf 2005
rm -rf 2006
rm -rf 2007
rm -rf 2008
rm -rf 2009
rm -rf 2010
rm -rf 2011
rm -rf 2012
rm -rf 2013
rm -rf 2014
rm -rf 2015
rm -rf 2016
rm -rf 2017
rm *.300


zip synonyms.zip synonyms.json synonyms2.json
rm synonyms.json
rm synonyms2.json
